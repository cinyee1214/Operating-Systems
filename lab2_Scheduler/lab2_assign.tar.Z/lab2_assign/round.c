#include <stdio.h>
main()
{
double a,b;
a = 1.0/3.0;
b = 2.0/3.0;
printf("%.2lf %.2lf\n", a, b);
printf("%.3lf %.3lf\n", a, b);
}
